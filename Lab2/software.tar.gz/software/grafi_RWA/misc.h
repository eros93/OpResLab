#ifndef _MISC_
#define _MISC_

#define MAX_INT INT_MAX

#endif
